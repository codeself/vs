#ifndef MODEL_BEHAVIOR_HEADER
#define MODEL_BEHAVIOR_HEADER

#include "auparse.h"
#include "ids_config.h"

void process_behavior_model(auparse_state_t *au,
	struct ids_conf *config);

#endif
