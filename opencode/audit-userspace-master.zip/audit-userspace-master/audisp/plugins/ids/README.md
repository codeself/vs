This is an experimental Intrusion Detection System (IDS) plugin. It's goal
is to either identify or react to suspicious activity. This is a work in
progress and is subject to either be completed or dropped in it's entirity
at its author's descretion.

So, if you would like to test it and report issues or even contribute code
feel free to do so. But please discuss the contribution first to ensure
that its acceptable. This project uses the Linux Kernel Style Guideline.
Please follow it if you wish to contribute.
