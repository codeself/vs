#ifndef MODEL_BAD_EVENT_HEADER
#define MODEL_BAD_EVENT_HEADER

#include "auparse.h"
#include "ids_config.h"

void process_bad_event_model(auparse_state_t *au,
	struct ids_conf *config);

#endif
