
#ifndef NTL_version__H
#define NTL_version__H

#define NTL_VERSION "11.5.1"

#define NTL_MAJOR_VERSION  (11)
#define NTL_MINOR_VERSION  (5)
#define NTL_REVISION       (1)

#endif

